#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>
#include "PathfinderInterface.h"
using namespace std;

class Pathfinder: public PathfinderInterface
{
public:
  int maze[5][5][5];
  vector<string> path;

	Pathfinder() {
    srand ( time(NULL) );
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        for (int k = 0; k < 5; k++) {
          maze[i][j][k] = 1;
        }
      }
    }
  }
  virtual ~Pathfinder() {}

	string toString() const;

	void createRandomMaze();
	
	bool importMaze(string file_name);
	
	vector<string> solveMaze();

  bool findPath(int x, int y, int z);
};