#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>
#include <sstream>
#include <fstream>
#include "Pathfinder.h"
using namespace std;
	
	string Pathfinder::toString() const{
    string toReturn = "";
    for (int z = 0; z < 5; z++) {
      for (int y = 0; y < 5; y++) {
        for (int x = 0; x < 5; x++) {
          if (x == 0) {
            toReturn += to_string(maze[x][y][z]);
          }
          else {
            toReturn += ' ' + to_string(maze[x][y][z]);
          }
        }
        toReturn += "\n";
      }
      if (z != 4) {
        toReturn += "\n";
      }
    }
    return toReturn;
  }

	void Pathfinder::createRandomMaze() {
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        for (int k = 0; k < 5; k++) {
          if (i == 0 && j == 0 && k == 0) {
            maze[i][j][k] = 1;
          }
          else if (i == 4 && j == 4 && k == 4) {
            maze[i][j][k] = 1;
          }
          else {
            maze[i][j][k] = rand() % 2;
          }
        }
      }
    }
  }
	
	bool Pathfinder::importMaze(string file_name) {
    ifstream newMaze(file_name);
    int tempMaze[5][5][5];
    int x = 0;
    int y = 0;
    int z = 0;
    if (newMaze.is_open()) {
      string line;
      while(getline(newMaze,line)) {
        stringstream ss(line);
        string s;
        while(getline(ss,s, ' ')) {
          if (s.length() > 1) {
            return false;
          }
          tempMaze[x][y][z] = stoi(s);
          if (x >= 5) {
            return false;
          }
          x++;
        }
        x = 0;
        if (y > 5) {
            return false;
        }
        y++;
        if (line.empty()) {
          y = 0;
          z++;
        }
        if (z >= 5) {
            return false;
        }
      }
      if (tempMaze[0][0][0] == 1 && tempMaze[4][4][4] == 1) { //This also checks for a ful maze, since tempMaze[4][4][4] will not be 1 if the file doesn't go that far such as in invalid1.txt
        for (int i = 0; i < 5; i++) {
          for (int j = 0; j < 5; j++) {
            for (int k = 0; k < 5; k++) {
              maze[i][j][k] = tempMaze[i][j][k];
            }
          }
        }
        return true;
      }
      else {
        return false;
      }
    }
    else {
      cout << "Error: Unable to open file" << file_name << endl;
      return false;
    }
  }

	vector<string> Pathfinder::solveMaze() {
    path.clear();
    findPath(0,0,0);
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        for (int k = 0; k < 5; k++) {
          if (maze[i][j][k] == 2) {
            maze[i][j][k] = 1;
          }
        }
      }
    }
    return path;
  }

  bool Pathfinder::findPath(int x, int y, int z) {
    string log = "(";
    log += to_string(x);
    log += ", ";
    log += to_string(y);
    log += ", ";
    log += to_string(z);
    log += ")";
    path.push_back(log);
    //Base cases
    if (x < 0 || y < 0 || z < 0 || x > 4 || y > 4 || z > 4) { //Outside of maze
      path.pop_back();
      return false;
    }
    else if (maze[x][y][z] == 0) { //Closed location
      path.pop_back();
      return false;
    }
    else if (maze[x][y][z] == 2) { //Have been here
      path.pop_back();
      return false;
    }
    else if (x == 4 && y == 4 && z == 4) {
      return true;
    }
    //Recursive Part
    maze[x][y][z] = 2;
    if (findPath(x+1,y,z)) {
      return true;
    }
    else if (findPath(x-1,y,z)) {
      return true;
    }
    else if (findPath(x,y+1,z)) {
      return true;
    }
    else if (findPath(x,y-1,z)) {
      return true;
    }
    else if (findPath(x,y,z+1)) {
      return true;
    }
    else if (findPath(x,y,z-1)) {
      return true;
    }
    else {
      path.pop_back();
      return false;
    }
  }